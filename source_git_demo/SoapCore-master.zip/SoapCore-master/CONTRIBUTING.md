# Contributing
We are greating for all improvements, bug fixes and new features if it not break exists behaviour.

## Code style
Code style described in stylecop ruleset file, checks perform on compile time. All violations of rules breaks project build.
Principal moments:
* use tabs
* private fields named with prefix "_"

## PR
For PR need:
* Issue described what problem you solve
* Code passed travis build (starts automatically)
* Code is covered by tests
