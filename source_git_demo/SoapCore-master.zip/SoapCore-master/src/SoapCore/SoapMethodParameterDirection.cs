namespace SoapCore
{
	public enum SoapMethodParameterDirection
	{
		InOnly,
		OutOnlyRef,
		InAndOutRef
	}
}
