using System.Runtime.Serialization;

namespace SoapCore.Tests.Model
{
	[DataContract]
	public class ComplexModelInputForModelBindingFilter : ComplexModelInput
	{
		//empty
	}
}
