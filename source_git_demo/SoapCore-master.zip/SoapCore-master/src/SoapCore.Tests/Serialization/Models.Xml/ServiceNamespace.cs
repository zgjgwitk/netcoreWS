namespace SoapCore.Tests.Serialization.Models.Xml
{
	public static class ServiceNamespace
	{
		public const string Value = "http://sampleservice.net/webservices/";
	}
}
